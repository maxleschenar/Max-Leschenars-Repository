﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject ball;
    ballscript sc;

    public GameObject Player1Text;
    public GameObject Player2Text;

    int Player1Scorehere;
    int Player2Scorehere;
    // Start is called before the first frame update
    void Start()
    {
        sc = ball.GetComponent<ballscript>();
    }

    // Update is called once per frame
    void Update()
    {
        Player1Scorehere = sc.Player1score;
        Player2Scorehere = sc.Player2score;
        Player1Text.GetComponent<TextMeshProUGUI>().text = Player1Scorehere.ToString();
        Player2Text.GetComponent<TextMeshProUGUI>().text = Player2Scorehere.ToString();
    }
}
