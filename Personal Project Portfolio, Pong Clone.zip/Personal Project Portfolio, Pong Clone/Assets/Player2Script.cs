﻿using System.Collections;
using UnityEngine;

public class Player2Script : MonoBehaviour
{
    public Rigidbody2D rb;
    public float Speed;
    float movement;
    public Vector3 Startposition;
    // Start is called before the first frame update
    void Start()
    {
        Startposition = transform.position; 
    }


    // Update is called once per frame
    void Update()
    {
        movement = Input.GetAxisRaw("Vertical2");
        rb.velocity = new Vector2(rb.velocity.x, movement * Speed);
    }

    public void Reset()
    {
        transform.position = Startposition;
    }
}
