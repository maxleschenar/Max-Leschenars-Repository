﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class Playerscript : MonoBehaviour
{
    public Rigidbody2D rb;
    public float Speed;
    float movement;
    public Vector3 Startposition;
    // Start is called before the first frame update
    void Start()
    {
        Startposition = transform.position;
    }


    // Update is called once per frame
    void Update()
    {

        movement = Input.GetAxisRaw("Vertical");

        rb.velocity = new Vector2(rb.velocity.x, movement * Speed);
    }
    public void Reset()
    {
        transform.position = Startposition;
    }
}
