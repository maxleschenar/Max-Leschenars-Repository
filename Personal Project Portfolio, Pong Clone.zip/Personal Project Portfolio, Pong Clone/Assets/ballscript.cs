﻿
using System.Collections;
using UnityEngine;

public class ballscript : MonoBehaviour
{
    public float speed;
    public Rigidbody2D rb;
    public Vector3 Startposition;
    [HideInInspector] public int Player1score = 0;
    [HideInInspector] public int Player2score = 0;
    // Start is called before the first frame update
    void Start()
    {
        Startposition = transform.position;
        Startgame();
    }

    // Update is called once per frame
    void Update()
    {
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player1goal")
        {
            Debug.Log("Player 2 Scores");
            Player2score = Player2score +1;
            Reset();
        }
        if (other.gameObject.tag == "Player2goal")
        {
            Debug.Log("Player 1 Scores");
            Player1score = Player1score + 1;
            Reset();

        }
    }

    void Startgame()
    {
        float x = Random.Range(0, 2) == 0 ? -1 : 1;
        float y = Random.Range(0, 2) == 0 ? -1 : 1;
        rb.velocity = new Vector2(speed * x, speed * y);
    }

    public void Reset()
    {
        Debug.Log("reset");
        rb.velocity = Vector2.zero; 
        transform.position = Startposition;
        Invoke("Startgame", 2);
    }
}
