﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class jetpackscript : MonoBehaviour
{
    // Start is called before the first frame update
    public float jumpspeed = 1;
    public Rigidbody2D rb;
    public GameManager gameManager;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            Debug.Log("jump");
            rb.velocity = Vector2.up * jumpspeed;
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        gameManager.GameOver();
    }
}
