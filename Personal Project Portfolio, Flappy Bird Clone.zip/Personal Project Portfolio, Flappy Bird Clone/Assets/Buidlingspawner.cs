﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;

public class Buidlingspawner : MonoBehaviour
{
    public GameObject BuildingPrefab;
    public float Spawntime = 2;
    public float currenttime = 0;
    public float Buildingposvar;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (currenttime > Spawntime)
        {
            GameObject newBuidling = Instantiate(BuildingPrefab);
            newBuidling.transform.position = transform.position + new Vector3(0, Random.Range(-Buildingposvar, Buildingposvar), 0);
            currenttime = 0;
            Destroy(newBuidling, 10);
        }

        currenttime += Time.deltaTime;
    }

}
